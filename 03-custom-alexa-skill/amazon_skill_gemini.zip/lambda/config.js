// config.js
const GEMINI_API_KEY = 'AIzaSyCeUlGhBSe64BhMbRGE3zMQvdKAZQ1HASs';

module.exports = { GEMINI_API_KEY };